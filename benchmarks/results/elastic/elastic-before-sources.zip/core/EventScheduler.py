from __future__ import annotations

import asyncio
from collections import deque
from contextvars import Context as TaskContext, copy_context
from dataclasses import dataclass
import logging
from typing import TYPE_CHECKING, Any, Literal

from .Lifecycle import RuntimeOverloadedError
from .Ownership import same_owner

if TYPE_CHECKING:
    from .Context import Context
    from .Envelope import Envelope
    from .Runtime import Runtime

logger = logging.getLogger(__name__)
_QUEUE_METRICS = ("event_queue_depth", "events_active", "event_queue_capacity")
_WATERMARK = ("event_queue_watermark",)
_RECEIVED = ("events_received_total",)


@dataclass(slots=True)
class _Work:
    envelope: "Envelope"
    future: "asyncio.Future[Context]"
    adapter_id: str
    lane: tuple[str, str]
    snapshot: Any = None
    task: asyncio.Task[Any] | None = None
    owners: tuple[object, ...] = ()
    state: Literal["queued", "active", "finished"] = "queued"


class EventScheduler:
    """Bounded session lanes, synchronously pumped into isolated event tasks."""

    __slots__ = (
        "runtime", "capacity", "_global_limit", "session_backlog",
        "_lanes", "_ready", "_ready_set", "_active_sessions",
        "_adapter_active", "_adapter_queued", "_adapter_limits",
        "_queued", "_active", "_idle", "_accepting", "_started",
        "_aborting", "_pumping", "_pump_again", "_event_context",
        "_event_work", "_sequence",
    )

    def __init__(
        self,
        runtime: "Runtime",
        *,
        capacity: int = 256,
        global_limit: int = 16,
        session_backlog: int = 32,
    ) -> None:
        self.runtime = runtime
        self.capacity = capacity
        self._global_limit = global_limit
        self.session_backlog = session_backlog
        self._lanes: dict[tuple[str, str], deque[_Work]] = {}
        self._ready: deque[tuple[str, str]] = deque()
        self._ready_set: set[tuple[str, str]] = set()
        self._active_sessions: set[tuple[str, str]] = set()
        self._adapter_active: dict[str, int] = {}
        self._adapter_queued: dict[str, int] = {}
        self._adapter_limits: dict[str, int] = {}
        self._queued = self._active = self._sequence = 0
        self._idle = asyncio.Event()
        self._idle.set()
        self._accepting = self._started = self._aborting = False
        self._pumping = self._pump_again = False
        self._event_context: TaskContext | None = None
        self._event_work: dict[asyncio.Task[Any], _Work] = {}

    @property
    def global_limit(self) -> int:
        return self._global_limit

    @global_limit.setter
    def global_limit(self, value: int) -> None:
        self._global_limit = value
        self._pump()

    def configure_adapter(self, adapter_id: str, active_limit: int = 4) -> None:
        if active_limit < 1:
            raise ValueError("adapter active limit must be at least 1")
        self._adapter_limits[adapter_id] = active_limit
        self._pump()

    def start(self) -> None:
        self._event_context = copy_context()
        self._started = self._accepting = True
        self._pump()

    @property
    def queued(self) -> int:
        return self._queued

    @property
    def active(self) -> int:
        return self._active

    @property
    def idle(self) -> bool:
        return self._queued == 0 and self._active == 0

    @property
    def accepting(self) -> bool:
        return self._accepting and self._queued + self._active < self.capacity

    async def submit(
        self,
        envelope: "Envelope",
        *,
        adapter_id: str,
        reject: bool,
        snapshot: Any = None,
        wait: bool = True,
        owners: tuple[object, ...] = (),
    ) -> "Context | asyncio.Future[Context] | None":
        if not self._accepting or self._queued + self._active >= self.capacity:
            return self._reject(envelope, adapter_id, "capacity", reject)
        session_id = envelope.session_id
        if session_id is None:
            self._sequence += 1
            lane = (adapter_id, f"__unscoped__:{self._sequence}")
        else:
            lane = (adapter_id, session_id)
        queue = self._lanes.get(lane)
        if (
            queue is not None
            and session_id is not None
            and len(queue) >= self.session_backlog
        ):
            return self._reject(envelope, adapter_id, "session_backlog", reject)
        if queue is None:
            queue = self._lanes[lane] = deque()
        future = asyncio.get_running_loop().create_future()
        work = _Work(envelope, future, adapter_id, lane, snapshot, owners=owners)
        self.runtime._retain_event_owners(owners)
        queue.append(work)
        self._queued += 1
        self._adapter_queued[adapter_id] = self._adapter_queued.get(adapter_id, 0) + 1
        self._idle.clear()
        if not wait:
            future.add_done_callback(_consume_future)
        try:
            self._record_state(adapter_id, received_platform=envelope.platform)
            self._mark_ready(lane)
        except BaseException as error:
            self._fatal(error)
        self._pump()
        if not wait:
            return future
        try:
            return await future
        except asyncio.CancelledError:
            if work.state == "queued":
                self._discard_queued(work)
                self._pump()
            elif work.state == "active" and work.task is not None:
                work.task.cancel()
            future.cancel()
            raise

    def _reject(
        self, envelope: "Envelope", adapter_id: str, reason: str, reject: bool,
    ) -> None:
        self.runtime.metrics.inc("events_rejected_total", labels={
            "platform": envelope.platform, "adapter": adapter_id, "reason": reason,
        })
        if reject:
            message = (
                "runtime event capacity is full"
                if reason == "capacity"
                else "session event backlog is full"
            )
            raise RuntimeOverloadedError(message)
        return None

    def _mark_ready(self, lane: tuple[str, str]) -> None:
        if (
            lane not in self._active_sessions
            and lane not in self._ready_set
            and self._lanes.get(lane)
        ):
            self._ready.append(lane)
            self._ready_set.add(lane)

    def _pump(self) -> None:
        if not self._started or self._aborting:
            return
        if self._pumping:
            self._pump_again = True
            return
        self._pumping = True
        work = None
        try:
            while True:
                self._pump_again = False
                scans = len(self._ready)
                while self._active < self._global_limit and scans and not self._aborting:
                    scans -= 1
                    lane = self._ready.popleft()
                    self._ready_set.discard(lane)
                    adapter_id = lane[0]
                    active = self._adapter_active.get(adapter_id, 0)
                    if active >= self._adapter_limits.get(adapter_id, 4):
                        self._mark_ready(lane)
                        continue
                    queue = self._lanes.get(lane)
                    if not queue:
                        self._lanes.pop(lane, None)
                        continue
                    work = queue.popleft()
                    work.state = "active"
                    self._queued -= 1
                    self._adapter_queued[adapter_id] -= 1
                    if not self._adapter_queued[adapter_id]:
                        self._adapter_queued.pop(adapter_id)
                    self._active += 1
                    self._adapter_active[adapter_id] = active + 1
                    self._active_sessions.add(lane)
                    self._record_state(adapter_id)
                    self._launch(work)
                if not self._pump_again or self._aborting:
                    break
        except BaseException as error:
            self._fatal(error)
            if work is not None and work.state == "active" and work.task is None:
                if not work.future.done():
                    work.future.set_exception(error)
                self._finish_work(work)
        finally:
            self._pumping = False

    def _launch(self, work: _Work) -> None:
        context = self._event_context.copy()
        coroutine = self._execute(work)
        try:
            task = context.run(
                self.runtime.tasks.spawn,
                coroutine,
                name=f"event:{work.envelope.event_id}",
                owner="events",
                critical=False,
            )
        except BaseException:
            coroutine.close()
            raise
        work.task = task
        self._event_work[task] = work
        task.add_done_callback(self._event_done, context=self._event_context.copy())

    async def _execute(self, work: _Work) -> None:
        try:
            ctx = await self.runtime._dispatch(work.envelope, self._queued, work.snapshot)
            if not work.future.done():
                work.future.set_result(ctx)
        except asyncio.CancelledError:
            work.future.cancel()
            raise
        except BaseException as error:
            if not work.future.done():
                work.future.set_exception(error)
        finally:
            self._finish_work(work)

    def _finish_work(self, work: _Work) -> None:
        if work.state == "finished":
            return
        try:
            previous, work.state = work.state, "finished"
            self.runtime._release_event_owners(work.owners)
            if previous == "active":
                self._active -= 1
                self._adapter_active[work.adapter_id] -= 1
                if not self._adapter_active[work.adapter_id]:
                    self._adapter_active.pop(work.adapter_id)
                self._active_sessions.discard(work.lane)
            else:
                self._queued -= 1
                self._adapter_queued[work.adapter_id] -= 1
                if not self._adapter_queued[work.adapter_id]:
                    self._adapter_queued.pop(work.adapter_id)
            if not self._lanes.get(work.lane):
                self._lanes.pop(work.lane, None)
                self._ready_set.discard(work.lane)
                try:
                    self._ready.remove(work.lane)
                except ValueError:
                    pass
            else:
                self._mark_ready(work.lane)
            if self.idle:
                self._idle.set()
            self._record_state(work.adapter_id)
            if previous == "active":
                self._pump()
        except BaseException as error:
            self._fatal(error)

    def _discard_queued(self, work: _Work) -> None:
        if work.state != "queued":
            return
        self._lanes[work.lane].remove(work)
        work.future.cancel()
        self._finish_work(work)

    def _event_done(self, task: asyncio.Task[Any]) -> None:
        work = self._event_work.pop(task, None)
        if work is not None and work.state != "finished":
            # Pre-start cancellation never enters _execute's finally block.
            if not work.future.done():
                if task.cancelled():
                    work.future.cancel()
                else:
                    error = task.exception()
                    if error is not None:
                        work.future.set_exception(error)
            self._finish_work(work)

    def _fatal(self, error: BaseException) -> None:
        if not self._aborting:
            logger.error("event scheduler failed: %s", error, exc_info=error)
        self._accepting = False
        self._aborting = True
        self._idle.set()
        self.runtime._request_critical_abort(error)

    def stop_admission(self) -> None:
        self._accepting = False
        self._pump()

    def request_abort(self) -> None:
        self._aborting = True
        self._idle.set()

    async def drain(self, timeout: float) -> bool:
        try:
            async with asyncio.timeout(timeout):
                while not self.idle:
                    if self._aborting or self.runtime._stop_requested == "abort":
                        return False
                    await self._idle.wait()
                return True
        except TimeoutError:
            return False

    async def abort(self, grace: float = 1.0) -> tuple[str, ...]:
        self._accepting = False
        self.request_abort()
        queued = tuple(work for queue in self._lanes.values() for work in queue)
        for work in queued:
            self._discard_queued(work)
        tasks = tuple(
            task for task, work in self._event_work.items()
            if work.state == "active"
        )
        for task in tasks:
            task.cancel()
        if tasks:
            _, pending = await asyncio.wait(tasks, timeout=grace)
        else:
            pending = set()
        return tuple(task.get_name() for task in pending)

    def _record_state(
        self, adapter_id: str, *, received_platform: str | None = None,
    ) -> None:
        metrics = self.runtime.metrics
        queued = self._adapter_queued.get(adapter_id, 0)
        active = self._adapter_active.get(adapter_id, 0)
        labels = {"adapter": adapter_id}
        updates = [
            ("set", metrics._bind(_QUEUE_METRICS), (self._queued, self._active, self.capacity)),
            ("set", metrics._bind(_QUEUE_METRICS, labels), (queued, active, self.capacity)),
        ]
        if received_platform is not None:
            updates.extend((
                ("max", metrics._bind(_WATERMARK), (self._queued + self._active,)),
                ("max", metrics._bind(_WATERMARK, labels), (queued + active,)),
                ("inc", metrics._bind(_RECEIVED, {"platform": received_platform, "adapter": adapter_id}), (1.0,)),
            ))
        metrics._batch(tuple(updates))

    async def cancel_owner(self, owner: object, grace: float = 1.0) -> tuple[str, ...]:
        queued = tuple(
            work for queue in self._lanes.values() for work in queue
            if any(same_owner(item, owner) for item in work.owners)
        )
        for work in queued:
            self._discard_queued(work)
        tasks = tuple(
            task for task, work in self._event_work.items()
            if work.state == "active"
            and any(same_owner(item, owner) for item in work.owners)
        )
        for task in tasks:
            task.cancel()
        self._pump()
        if tasks:
            _, pending = await asyncio.wait(tasks, timeout=grace)
        else:
            pending = set()
        return tuple(task.get_name() for task in pending)


def _consume_future(future: asyncio.Future[Any]) -> None:
    if not future.cancelled():
        future.exception()
