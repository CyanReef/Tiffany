"""Render measured elastic-scheduler results without replacing old reports."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from benchmarks.elastic_validate import validate, verify_source

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'benchmarks/results'


def read(name):
    return json.loads((RESULTS / name).read_text(encoding='utf-8'))


def verify_archives(sources):
    for entry in sources.values():
        verify_source(entry['source'])
        path = RESULTS / entry['archive']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['archive_sha256']
        with zipfile.ZipFile(path) as archive:
            manifest = json.loads(archive.read('baseline-manifest.json'))
            for name, digest in manifest['files'].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
            for name, digest in entry['source']['files'].items():
                assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name


def render():
    normal = read('tiffany-elastic-normal-v2-15.json')
    closed = read('tiffany-elastic-http-closed.json')
    arrivals = read('tiffany-elastic-http-arrivals.json')
    warm = read('tiffany-elastic-http-arrivals-warm.json')
    parallel = read('tiffany-elastic-http-arrivals-512.json')
    soak = read('tiffany-elastic-soak.json')
    sources = read('tiffany-elastic-sources.json')
    checks = [validate(data) for data in (normal, closed, arrivals, soak)]
    validate(warm)
    validate(parallel)
    verify_archives(sources)
    assert sources['after']['source'] == normal['candidate_source'] == soak['source']
    assert sources['final']['source'] == closed['candidate_source'] == arrivals['candidate_source']
    assert warm['candidate_source'] == sources['final']['source']
    assert parallel['candidate_source'] == sources['final']['source']
    old, final = sources['after']['source']['files'], sources['final']['source']['files']
    assert [name for name in final if old.get(name) != final[name]] == ['adapters/QQOfficialWebSocketAdapter.py']
    lines = ['# Tiffany 弹性调度性能验收', '',
        '基线来自实施前当前工作区的源码快照，包含已有未提交优化。没有用旧 Git HEAD 替代。原性能报告和中间未通过数据保留，新结果单独存放。', '',
        '共享预算、保留额度、同会话 FIFO、同步接纳和 Adapter drain 的接口见 [调度说明](ELASTIC_SCHEDULING.md)。本轮没有单会话并行、持久化队列、后台调参或新增运行依赖。', '',
        '## 环境与方法', '',
        f"Windows 11，CPython 3.12.14；aiohttp {normal['environment']['packages']['aiohttp']}、websockets {normal['environment']['packages']['websockets']}、psutil {normal['environment']['packages']['psutil']}。性能使用已有扩展测量环境，两侧使用同解释器与依赖，真实 MetricRegistry 开启、Trace 关闭、GC 开启。没有在共享 CI 上设置速度门槛。", '',
        '正常场景每轮、每个实现使用独立进程，轮次交替先后顺序，每个场景预热 1000 条，计时 60000 条。首轮 7 次因配对区间跨过 97% 门槛，按相同条件补至 15 次；没有丢弃原 7 轮。计时场景最短 2.82 秒。吞吐为完成量除以计时，延迟覆盖提交到业务完成；RSS 为各场景预热后空闲采样。', '',
        '完整 OneBot 场景从 JSON 帧编码、解码、会话键和预算接纳，到 Hook 完成；它是离线帧入口，不包含真实平台网络和回复时间。真正 WebSocket 满载时的 echo、ping 和 drain 另有本机集成测试。', '',
        '## 正常负载', '',
        '| 场景 | 基线 events/s | 新实现 events/s | 吞吐变化 | P95 变化 | P99 变化 | RSS 变化 | 配对吞吐中位数 95% 区间 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
    summaries = {(row['profile'], row['case']): row for row in normal['summary']}
    labels = {'one_handler': '单 Hook', 'ten_handlers': '10 Hook', 'unmatched_1000': '1000 个无关 Hook',
              'reads_16': '缓存字段读 16 次', 'text_64k': '64 KiB 文本', 'onebot_frames': '完整 OneBot 帧'}
    for row in normal['acceptance']:
        case, ratios = row['case'], row['ratios']
        b, a = summaries['before', case], summaries['after', case]
        changes = ' | '.join(f'{(ratios[k]-1)*100:+.2f}%' for k in ('throughput', 'p95_us', 'p99_us', 'rss_bytes'))
        lo, hi = row['paired_median_95_percent_interval']
        lines.append(f"| {labels[case]} | {b['throughput']['median']:,.0f} | {a['throughput']['median']:,.0f} | {changes} | {lo*100:.2f}%–{hi*100:.2f}% |")
    lines += ['', f"正常负载验收：**{'通过' if checks[0]['passed'] else '未通过'}**。要求吞吐至少 97%、P95 增幅不超过 5%、P99 不超过 10%、RSS 不超过 5%；15 轮后仍跨过 97% 的配对区间判为未通过。区间采用固定随机种子的配对中位数 bootstrap，4000 次重采样；这是所测工作站的波动估计，不是线上性能保证。原始数据另有每轮配对比值和每项指标最小–最大范围。", '',
        '## HTTP 高负载', '',
        '本机 HTTP 服务实际等待至少 5/50/500 ms，由 64 个预热线程负责等待。会话数为 1/16/64/256。每个条件在独立进程比较旧默认（总容量 256、会话积压 32、全局 16、Adapter 4）、旧调优（容量和积压 8192、全局和 Adapter 64）以及新默认。客户端 HTTP 连接上限统一为 64；这不代表 QQ 的下游 API 额度会自动提高。', '',
        '闭环每个生产者等待完成后再提交，窗口 2.5 秒，窗口末尾的工作排空时间计入吞吐。固定到达使用同一预定速率 `1.5 × min(会话数, 64) / HTTP延迟`；事件循环调度可能造成短暂追赶，原始数据记录实际到达窗口。突发一次提交后等待排空。5/50 ms 的多会话条件提交 512 条，其余条件提交 64 条；同一条件三种实现的提交量和预定到达速率相同。', '',
        '### 闭环完成吞吐（7 轮中位数）', '',
        '| HTTP ms | 会话数 | 旧默认 events/s | 旧调优 events/s | 新默认 events/s | 新 / 旧调优 | P95 比值 | P99 比值 |',
        '| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    index = {(row['profile'], row['case']): row for row in closed['summary']}
    for check in closed['acceptance']:
        case = check['case']
        old, tuned, new = [index[p, case] for p in ('before', 'before_tuned', 'after')]
        r = check['ratios']
        lines.append(f"| {new['delay_ms']['median']:g} | {new['sessions']['median']:g} | {old['throughput']['median']:.1f} | {tuned['throughput']['median']:.1f} | {new['throughput']['median']:.1f} | {r['throughput']:.3f} | {r['p95_ms']:.3f} | {r['p99_ms']:.3f} |")
    lines += ['', f"闭环验收：**{'通过' if checks[1]['passed'] else '未通过'}**。同有效并发、无拒绝时，吞吐至少为旧调优的 95%，P95/P99 增幅不超过 10%。有效并发由 Hook 内活动计数实测，未把接纳量当作完成吞吐。", '',
        '### 固定到达与突发排空', '',
        '| 条件 | 旧默认完成 / 提交 | 新完成 / 提交 | 旧调优排空 s | 新排空 s | 新 / 旧调优吞吐 | P95 比值 | P99 比值 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    index = {(row['profile'], row['case']): row for row in arrivals['summary'] if row['delay_ms']['median'] == 500}
    index.update({(row['profile'], row['case']): row for row in warm['summary'] if row['sessions']['median'] == 1})
    index.update({(row['profile'], row['case']): row for row in parallel['summary']})
    arrival_checks = ([row for row in arrivals['acceptance'] if '_0.5_' in row['case']]
                      + [row for row in warm['acceptance'] if row['case'].endswith('_1')]
                      + parallel['acceptance'])
    for check in arrival_checks:
        case = check['case']
        old, tuned, new = [index[p, case] for p in ('before', 'before_tuned', 'after')]
        r = check['ratios']
        lines.append(f"| {case} | {old['completed']['median']:g}/{old['offered']['median']:g} | {new['completed']['median']:g}/{new['offered']['median']:g} | {tuned['seconds']['median']:.3f} | {new['seconds']['median']:.3f} | {r['throughput']:.3f} | {r['p95_ms']:.3f} | {r['p99_ms']:.3f} |")
    lines += ['', f"固定到达 / 突发验收：**{'通过' if all(row['passed'] for row in arrival_checks) else '未通过'}**。5/50 ms 使用连接预热后的 7 轮中位数；500 ms 为原单轮结果，不提供多轮统计结论。最初仅预热 4 次、短测包含新连接建立的结果出现较大波动，多个条件未通过。自动预热后的 64 条 / 7 轮测量仍有两个 5 ms 突发条件吞吐未达 95%：64 会话为 93.95%、256 会话为 94.65%。多会话改为 512 条复测，覆盖全部 256 个会话并减少短计时影响；三批原始数据完整保留。后续预热 `max(4, min(会话数, 64))` 次，没有改变生产代码、额度或验收门槛。超出预算另有 9000 条过载回归：8192 条接纳、808 条明确拒绝，64 个活动 Task，排空后恢复。保留区和大事件先耗尽字节预算均单独测试。", '',
        '## 30 分钟稳定性', '',
        f"实际运行 {soak['seconds']:.2f} 秒，{len(soak['samples'])} 轮，完成 {soak['samples'][-1]['calls']:,} 条。每轮循环 128 条单会话、512 条/16 会话、4096 条/64 会话突发，排空后等待约 10 秒再继续。每轮断言预算、会话队列、就绪队列、活动工作映射、Task 和 owner 引用归零。GC 后 Context 与 Work 保留量为 0，同阶段 Future 数量没有增长。", '',
        f"排空后 RSS 范围 {min(row['rss_bytes'] for row in soak['samples'])/1024/1024:.2f}–{max(row['rss_bytes'] for row in soak['samples'])/1024/1024:.2f} MiB；允许 Python 分配器保留内存，不要求返回冷启动值。估算预算不包含 Hook 自行分配的对象及调用方保留的结果，不能当作进程 RSS 硬限制。稳定性期间的源码摘要保持不变。", '',
        '## 源码与原始数据', '',
        f"基线生产源码摘要：`{normal['baseline_source']['sha256']}`。正常采样及稳定性源码摘要：`{normal['candidate_source']['sha256']}`。最终源码与 HTTP 采样摘要：`{closed['candidate_source']['sha256']}`。", '',
        '正常采样后仅补齐 QQ `stop(drain)` 等待本 Adapter 在途事件的冷路径。正常与稳定性测量不导入 QQ Adapter，所有被测核心、OneBot、Client 和共享策略文件的逐文件哈希与最终代码完全一致；[源码清单](../benchmarks/results/tiffany-elastic-sources.json) 保留这一差异，没有修改原始采样的摘要。QQ 冷路径通过单独生命周期测试。', '',
        '- [正常 15 轮原始数据](../benchmarks/results/tiffany-elastic-normal-v2-15.json)',
        '- [闭环 HTTP 原始数据](../benchmarks/results/tiffany-elastic-http-closed.json)',
        '- [固定到达 / 突发原始数据](../benchmarks/results/tiffany-elastic-http-arrivals.json)',
        '- [连接预热后 7 轮固定到达 / 突发数据](../benchmarks/results/tiffany-elastic-http-arrivals-warm.json)',
        '- [512 条 / 7 轮多会话固定到达与突发数据](../benchmarks/results/tiffany-elastic-http-arrivals-512.json)',
        '- [30 分钟原始数据](../benchmarks/results/tiffany-elastic-soak.json)',
        '- [实施前工作区源码](../benchmarks/results/elastic-before-sources.zip)、[正常采样源码](../benchmarks/results/elastic-after-sources.zip)、[最终源码](../benchmarks/results/elastic-final-sources.zip)', '',
        '初版七轮和十五轮未通过区间判断的数据也保留为 `tiffany-elastic-normal-7.json`、`tiffany-elastic-normal.json`；最终版首批七轮为 `tiffany-elastic-normal-v2.json`。未完成的中断诊断不作为验收数据。', '',
        '## 复测', '',
        '使用同一 Python 环境运行两侧；本次使用 `.build-cache/expanded-python-env/Scripts/python.exe`。所需测量依赖为 aiohttp、psutil、websockets，本项目现有扩展测量锁文件可复用，不改变核心依赖。恢复 ZIP 到独立目录后，`--baseline` / `--source` 指向相应目录；快照中的 manifest 会逐文件检查。', '',
        '```powershell',
        '$elasticPython = ".\\.build-cache\\expanded-python-env\\Scripts\\python.exe"',
        '& $elasticPython -B -m benchmarks.elastic --baseline .build-cache/elastic/before --source .build-cache/elastic/final-v2 --repeats 15 --events 60000 --output .build-cache/elastic/repeat-normal.json',
        '& $elasticPython -B -m benchmarks.elastic --suite http --baseline .build-cache/elastic/before --source .build-cache/elastic/final-v3 --repeats 7 --loads closed --http-warmup 4 --output .build-cache/elastic/repeat-http.json',
        '& $elasticPython -B -m benchmarks.elastic --suite http --baseline .build-cache/elastic/before --source .build-cache/elastic/final-v3 --repeats 1 --loads open burst --load-events 64 --http-warmup 4 --output .build-cache/elastic/repeat-arrivals.json',
        '& $elasticPython -B -m benchmarks.elastic --suite http --baseline .build-cache/elastic/before --source .build-cache/elastic/final-v3 --repeats 7 --delays .005 .05 --loads open burst --load-events 64 --output .build-cache/elastic/repeat-arrivals-warm.json',
        '& $elasticPython -B -m benchmarks.elastic --suite http --baseline .build-cache/elastic/before --source .build-cache/elastic/final-v3 --repeats 7 --delays .005 .05 --session-counts 16 64 256 --loads open burst --load-events 512 --output .build-cache/elastic/repeat-arrivals-512.json',
        '& $elasticPython -B -m benchmarks.elastic --soak --source .build-cache/elastic/final-v2 --seconds 1800 --output .build-cache/elastic/repeat-soak.json',
        '& $elasticPython -B -m benchmarks.elastic_validate benchmarks/results/tiffany-elastic-normal-v2-15.json benchmarks/results/tiffany-elastic-http-closed.json benchmarks/results/tiffany-elastic-http-arrivals.json benchmarks/results/tiffany-elastic-http-arrivals-warm.json benchmarks/results/tiffany-elastic-http-arrivals-512.json benchmarks/results/tiffany-elastic-soak.json',
        'python -B -m unittest discover -s tests -t . -q', '```', '',
        '首次 7 轮无法区分 3% 回退与噪声时，可用 `--resume 原七轮.json --repeats 15 --output 新十五轮.json` 补齐；它要求源码、解释器、依赖和测量参数完全一致。独立校验脚本从逐轮数据重算汇总、完成量、指标、源码摘要和验收结果。', '',
        '本机完整回归使用 Windows CPython 3.14.4：234 项，4 项按平台跳过，全部通过；更新包生成和 data 排除检查通过。Linux 3.11–3.14、Windows 3.11/3.14 的原 CI 矩阵保留，本轮没有运行远端矩阵。额外 3.12 扩展环境诊断缺少 prometheus-client，且并行诊断中有一项短超时 HTTP 测试波动，未作为完整回归验收；正式性能采样不需要 exporter 依赖，其业务指标为真实注册表。', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / '.build-cache/elastic/PERFORMANCE_ELASTIC.md')
    args = parser.parse_args()
    text = render()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text, encoding='utf-8')
    print(args.output)


if __name__ == '__main__':
    main()
